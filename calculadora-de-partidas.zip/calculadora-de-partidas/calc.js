/*Calculadora de partidas Rankeadas
**O Que deve ser utilizado**

- Variáveis
- Operadores
- Laços de repetição
- Estruturas de decisões
- Funções

## Objetivo:

Crie uma função que recebe como parâmetro a quantidade de vitórias e derrotas de um jogador,
depois disso retorne o resultado para uma variável, o saldo de Rankeadas deve ser feito através do calculo (vitórias - derrotas)

Se vitórias for menor do que 10 = Ferro
Se vitórias for entre 11 e 20 = Bronze
Se vitórias for entre 21 e 50 = Prata
Se vitórias for entre 51 e 80 = Ouro
Se vitórias for entre 81 e 90 = Diamante
Se vitórias for entre 91 e 100= Lendário
Se vitórias for maior ou igual a 101 = Imortal

## Saída

Ao final deve se exibir uma mensagem:
"O Herói tem de saldo de **{saldoVitorias}** está no nível de **{nivel}**"*/


let qntdd_vitoria, qntdd_derrota, saldo;
let nivel;


function ler(qntdd_derrota, qntdd_vitoria){
    return qntdd_vitoria - qntdd_derrota;
}

function classificar_nivel(qntdd_vitoria){
    if(quantidade_xp < 10){
        nivel = "Ferro";
    }
    else if(quantidade_xp >= 11 && quantidade_xp <= 20){
        nivel = "Bronze";
    }
    else if(quantidade_xp >= 21 && quantidade_xp <= 50){
        nivel = "Prata";
    }
    else if(quantidade_xp >= 51 && quantidade_xp <= 80){
        nivel = "Ouro";
    }
    else if(quantidade_xp >= 81 && quantidade_xp <= 90){
        nivel = "Diamante";
    }
    else if(quantidade_xp >= 91 && quantidade_xp <= 100){
        nivel = "Lendário";
    }
    else{
        nivel = "Imortal";
    }
}

do{
    qntdd_vitoria = parseInt(prompt("Por favor, informe a quantidade de vitórias:"));

    if(qntdd < 0){
        console.log("Quantidade invalida");
    }

    else{
        do{
            qntdd_derrota = parseInt(prompt("Por favor, informe a quantidade de derrotas:"));
        
            if(qntdd_derrota < 0){
                console.log("Quantidade invalida");
            }
        }  while(qntdd_derrota < 0);
    }

} while(qntdd_vitoria < 0);

saldo = ler(qntdd_derrota, qntdd_vitoria);
nivel = classificar_nivel(qntdd_vitoria);

console.log(`O Herói tem saldo de ${saldo} está no nível de ${nivel}`);

